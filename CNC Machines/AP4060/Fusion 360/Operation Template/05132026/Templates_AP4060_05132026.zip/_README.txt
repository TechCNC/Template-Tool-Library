Fusion 360 — Operation Templates Export
Generated: 2026-05-13_07-33-42
User: mkkar

Total templates: 63
Source operations (across 12 open CAM docs): 263
Operations deduplicated: 263 → 63 unique groups

Fusion library location: user://AP4060_new
Format: Fusion 360 operation template (.f3dhsm-template)

To re-import on another machine:
  Manufacture → Manage → Templates → right-click target folder →
  Import → select .f3dhsm-template files

================================================================================
TEMPLATE LIST (sorted by strategy → tool):
================================================================================

Name                                                                    Ops      Size
------------------------------------------------------------------------------------------
2D Adaptive D6 BB 6x24x75 x2                                              2    28.2KB
2D Adaptive D8 BB 8x24 (Cell-37) x5                                       5    27.8KB
2D Adaptive D8 BB 8x8x24 (cell-37)                                        1    28.7KB
2D Contour D3 3R0.2x4x50 (Cell-64)                                        1    31.6KB
2D Contour D4 4x12(Cell-33) x6                                            6    30.7KB
2D Contour D4 4x12(Cell-33) x6 #2                                         6    31.0KB
2D Contour D4 4x12(Cell-33) x2                                            2    31.0KB
2D Contour D4 4x15(Cell-33) x4                                            4    37.9KB
2D Contour D4 4x15(Cell-33) x7                                            7    30.8KB
2D Contour D4 BB 4x12 (Cell-34) x3                                        3    71.6KB
2D Contour D4 BB 4x12 (Cell-34)                                           1    32.5KB
2D Contour D4 Chamfer-D4 (Cell-25) x14                                   14    30.4KB
2D Contour D6 BB 6R1x50L x11                                             11    32.6KB
2D Contour D6 BB 6x24x75                                                  1    32.0KB
2D Contour D6 Chamfer-D6 (Cell-26) x16                                   16    33.4KB
2D Contour D6 Chamfer-D6 (Cell-26) x2                                     2    30.1KB
2D Contour D8 BB 8x24 (Cell-37) x6                                        6    30.0KB
2D Contour D8 BB 8x8x24 (cell-37) x41                                    41    30.4KB
2D Contour D8 BB 8x8x24 (cell-37) x2                                      2    31.0KB
2D Contour D8 Chamfer-D8 (Cell-28)                                        1    34.5KB
2D Contour D10 10x30x75 Rough Cell-38 x2                                  2    29.8KB
2D Contour D10 BB 10x10x30x75 x2                                          2    31.6KB
2D Contour D10 ВD10x2 x2                                                  2    30.7KB
2D Pocket D6 BB 6R1x50L x9                                                9    28.8KB
2D Pocket D6 BB 6x24x75 x3                                                3    29.9KB
2D Pocket D8 BB 8x24 (Cell-37)                                            1    29.0KB
2D Pocket D8 BB 8x8x24 (cell-37) x8                                       8    28.5KB
2D Pocket D8 BB 8x8x24 (cell-37)                                          1    29.3KB
Drill D3.3 Drill D3.3 (Cell-3)                                            1    38.1KB
Drill D4 Chamfer-D4 (Cell-25)                                             1    42.3KB
Drill D4.2 Drill D4.2 (Cell-4) x2                                         2    41.9KB
Drill D4.2 Drill D4.2 (Cell-4) x4                                         4    44.1KB
Drill D4.2 Drill D4.2 (Cell-4)                                            1    44.4KB
Drill D5 Drill D5 (Cell-5)                                                1    43.3KB
Drill D5 Drill D5 (Cell-5) #2                                             1    39.0KB
Drill D5.2 Drill 5.2 (Cell-6)                                             1    42.5KB
Drill D5.5 Drill D5.5 (Cell-7)                                            1    41.8KB
Drill D6 Chamfer-D6 (Cell-26)                                             1    45.3KB
Drill D6.5 Drill D6.5 (Cell-10) x2                                        2    45.3KB
Drill D6.8 Drill D6.8 (Cell-11) x2                                        2    38.0KB
Drill D7.95 Drill D7.95 (Cell-14)                                         1    38.0KB
Drill D8 D8x40 Reamer x2                                                  2    37.9KB
Drill D8.2 Drill D8.2 (Cell-12) x2                                        2    40.3KB
Face D25 BAP300R-D25-H12-IN x5                                            5    22.2KB
Face D25 BAP300R-D25-H12-IN x2                                            2    23.7KB
Face D57 Cell-45 x2                                                       2    21.6KB
Slot D8 BB 8x24                                                           1    24.0KB
Thread Mill D3 M4x07 (Cell 49)                                            1    23.6KB
Thread Mill D4 M5x08 (Cell 46) x2                                         2    24.6KB
Thread Mill D5 M6x1 (Cell 47) x3                                          3    23.4KB
Thread Mill D5 M6x1 (Cell 47)                                             1    25.3KB
Thread Mill D6 M8x1.25 (Cell 48) x5                                       5    25.7KB
Trace D1.5 D1.5 x7                                                        7    24.3KB
Trace D6 2F R3 10xD6x50 (Cell-32) x26                                    26    24.2KB
Trace D6 Chamfer-D6 (Cell-26) x2                                          2    25.9KB
Trace D6 Chamfer-D6 (Cell-26) x2 #2                                       2    24.2KB
Trace D8 BB 8x24                                                          1    23.0KB
Trace D8 Chamfer-D8 (Cell-28) x2                                          2    24.8KB
adaptive D4 BB 4x12 (Cell-34)                                             1    29.6KB
adaptive D6 BB 6R1x50L x6                                                 6    29.5KB
blend D6 BB 6R1x50L x5                                                    5    38.4KB
morphed_spiral D5 2F R2.5x5x75 BB (Cell-55) x2                            2    37.2KB
scallop D4 AL-2B-R2.0 (Cell-29) x4                                        4    41.6KB
